package com.example.Kursuva.Rabota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KursuvaRabotaApplication {

	public static void main(String[] args) {

		SpringApplication.run(KursuvaRabotaApplication.class, args);
	}

}
