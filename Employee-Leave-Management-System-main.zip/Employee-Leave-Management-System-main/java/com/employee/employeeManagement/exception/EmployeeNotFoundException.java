package com.employee.employeeManagement.exception;
public class EmployeeNotFoundException extends Exception{

	public EmployeeNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}